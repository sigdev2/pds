%%=LINKS_TO_LOCALIZED%%

<p align="center">
    <img src="./docs/logo.png" alt="Logo" width="80" height="80">
    <h3 align="center">%%=PROJ_NAME%%</h3>
    <p align="center">Last version %%=VERSION%%</p>
</p>

## Table of Contents

* [About the Project](#about-the-project)
* [Getting Started](#getting-started)
* [Usage](#usage)
* [Contributing](#contributing)
* [License](#license)

## About The Project

You can read [The Change history](./CHANGELOG)

## Getting Started

For begin you may read [installation guide](./INSTALL)

## Usage

Read help for %%=PROJ_NAME%%

## Contributing

Please note we have a [Code of Conduct](./CODE_OF_CONDUCT.md)
All information about contributing you may read [here](./CONTRIBUTING.md)

## License

Distributed under the %%=LICENSE%% License.