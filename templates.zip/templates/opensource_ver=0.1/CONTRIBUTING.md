# Contributing to %%=PROJ_NAME%%

## Introduction

First off, thank you for considering contributing to %%=PROJ_NAME%%.

## How to help the project ?

There are many ways to contribute, from writing tutorials or blog posts, improving the documentation, submitting bug reports and feature requests or writing code.

## Ground Rules

Following these guidelines helps to communicate that you respect the time of the developers managing and developing this open source project. In return, they should reciprocate that respect in addressing your issue, assessing changes, and helping you finalize your pull requests.

When contributing to this repository, please first discuss the change you wish to make via issue,
email, or any other method with the owners of this repository before making a change.

Please note we have a [Code of Conduct](./CODE_OF_CONDUCT.md), please follow it in all your interactions with the project. Be welcoming to newcomers and encourage diverse new contributors from all backgrounds.

Follow the general style of writing code and adhere to the technical processes used. You can discuss all the innovations that you would like to see, and if the developer community approves them, we can change them.

## Your First Contribution

Unsure where to begin contributing to %%=PROJ_NAME%%? You can start by next variants:

 - Read opened issues, maybe you can solve them.
 - You can discuss ideas for improving the program with developers, propose your solution as a Pull Request.
 - If you find a bug or typo, then you can create a issue with its description and a possible way to solve it.

## Pull Request Process

Working on your first Pull Request? You can learn how from [this](http://makeapullrequest.com/). Feel free to ask for help.

For small contributions such as moving source files from one directory or package to another, fixing spelling errors, white space changes, formatting changes, comment clean up, adding logging messages, adding debugging output, small refactoring and one-chars bug fixing don't use Pull Request, enough create issue or email to developers.

For something that is bigger than a one or two line fix:

 1. Create your own fork of the code.
 2. Do the changes in your fork.

If you like the change and think the project could use it, before send Pull Request, check:

 1. Be sure you have followed the code style for the project.
 2. Note the [Code of Conduct](./CODE_OF_CONDUCT.md).
 3. Ensure any install or build dependencies and temporary files are removed before pull request.
 4. If required then update the README.md, CHANGELOG and INSTALL with details of changes. Documentate your code in documentation if need.
 5. Cover with tests your code if it is difficult to understand and debug.
 6. Increase the version numbers in all versions files and the README.md
 7. You may merge the Pull Request in once you have the sign-off of two other developers, or if you
��� do not have permission to do that, you may request the second reviewer to merge it for you.

If a maintainer asks you to "rebase" your Pull Request, they're saying that a lot of code has changed, and that you need to update your branch so it's easier to merge.

## How create issue ?

When filing an issue, make sure to answer these five questions:

 1. What computer equipment do you use?
 2. What environment does the program use? (operating system, processor architecture, third-party programs)
 3. What did you do?
 4. What did you expect to see?
 5. What did you see instead?

General questions should email instead of the issue tracker. The developers there will answer or ask you to file an issue if you've tripped over a bug.

## How to suggest a feature or enhancement?

Make sure your feature or enhancement is in line with the overall spirit of the project. To do this, discuss them in a issues or email with developers.