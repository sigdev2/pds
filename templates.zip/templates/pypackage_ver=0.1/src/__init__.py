#!/usr/bin/env python
# -*- coding: utf-8 -*-

from .%%=PROJ_NAME%% import *

__author__ = r'%%=AUTHOR%%'
__authors__ = r'%%=AUTHOR%%'
__contact__ = r'%%=EMAIL%%'
__copyright__ = r'Copyright (c) %%=CUR_YEAR%%, %%=AUTHOR%%'
__credits__ = [r'%%=AUTHOR%%']
__license__ = r'%%=LICENSE%%'
__version__ = r'%%=VERSION%%'
__revision__ = 1
__maintainer__ = r'%%=AUTHOR%%'
__email__ = r'%%=EMAIL%%'
__status__ = r'Alpha'
__date__ = r'%%=CUR_DATE%%'
__all__ = []
